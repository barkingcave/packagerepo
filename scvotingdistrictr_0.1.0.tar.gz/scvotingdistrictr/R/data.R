#' Spatial Polygon with South Carolina Voting Districts
"sp_scarolina"


